<?php
//loading common files required for processing
require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "messages" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}
else {
    $DumpTable = new DumpTable;
    $output = $DumpTable -> Dump_Tables($RoundID);
    if (empty($output)) {
        $errors = ['error'];
    }
}

//return results via Json
if (!empty($errors)) {
$result = [
    "status" => "error",
    ];
}
else {
    $result = $output;
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRESERVE_ZERO_FRACTION);
 ?>
