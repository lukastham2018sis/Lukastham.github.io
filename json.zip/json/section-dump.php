<?php
//loading common files required for processing
require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "messages" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$errors = [];
$errors = [isMissingOrEmpty ('course'),isMissingOrEmpty ('section')];
$errors = array_filter($errors);

//dump-section process will begin if there are no errors
if (empty($errors)) {
    $user_input = json_decode($_REQUEST['r']);
    $SectionID = $user_input -> section;
    $CourseID = $user_input -> course;
    //check if course exists
    $CourseDAO = new CourseDAO;
    $isok_course = $CourseDAO -> retrieveCourseByID($CourseID);
    if (!$isok_course) {
        $errors[] = 'invalid course';
    }
    else {
        $SectionDAO = new SectionDAO;
        $isok_section = $SectionDAO -> retrieveSectionDetailsBySectionCourse($CourseID, $SectionID);
        if (!$isok_section) {
            $errors[] = 'invalid section';
        }
        else {
            $BidHistoryDAO = new BidHistoryDAO();
            $output = $BidHistoryDAO -> getBidByCourseSection($CourseID,$SectionID);
        }
    }
}
//return results via Json
if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "message" => array_values($errors)
        ];
}
else {
    $result = [
        "status" => "success",
        "students" => $output
    ];
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION);

 ?>
