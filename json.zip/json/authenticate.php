<?php
require_once '../model/token.php';
require_once '../model/admin-master.php';
require_once 'json-common.php';

$errors = [];
$errors = [ isMissingOrEmpty ('username'),
            isMissingOrEmpty ('password') ];

$errors = array_filter($errors);

if (empty($errors)) {

    //check actual input
    $Username = $_POST['username'];
    $Password = $_POST['password'];

        $errors = [];
        if ($Username != $admin_user) {
            $errors[] = 'invalid username';
        }
        elseif ($Password != $admin_password) {
            $errors[] = 'invalid password';
        }
}

if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "message" => array_values($errors)
    ];
}
else {
    $token = generate_token($Username);

    $result = [
        "status" => "success",
        "token" => $token,
    ];
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
 ?>
