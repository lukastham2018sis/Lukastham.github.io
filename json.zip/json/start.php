<?php
require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "message" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$roundDAO= new RoundDAO();
$currentroundinfo = $roundDAO -> currentRound();
$currentroundid = $currentroundinfo[0] -> getRoundID();
$nextrounddata = $roundDAO -> UpcomingRounds();

$result = [];

if (empty($nextrounddata)) {
    $result = [
        "status" => "error",
        "message" => ["round 2 ended"]
    ];
}
elseif ($RoundID == 1 or $RoundID == 2) {
    $result = [
        "status" => "success",
        "round" => (int)$RoundID
    ];
}
elseif (sizeof($nextrounddata) == 2 && $RoundID == 0) {
    $RoundDAO -> StartRound(1,$today);
    $result = [
        "status" => "success",
        "round" => 1
    ];
}
elseif (sizeof($nextrounddata) == 1 && $RoundID == 0) {
    $RoundDAO -> StartRound(2,$today);
    $result = [
        "status" => "success",
        "round" => 2
    ];
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);

?>
