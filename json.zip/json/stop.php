<?php
require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
        "status" => "error",
        "message" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$roundDAO= new RoundDAO();
$currentroundinfo = $roundDAO -> currentRound();
$currentroundid = $currentroundinfo[0] -> getRoundID();
$roundend = $currentroundinfo[0]-> getRoundEnd();
$nextrounddata = $roundDAO -> UpcomingRounds();

$result = [];

if($currentroundid == 1 || $currentroundid == 2){
    $roundDAO -> EndRound($currentroundid,$today);
    $result = [
        "status" => "success"
    ];
}
elseif($currentroundid == 0){
    $result = [
        "status" => "error",
        "message" => ["round already ended"]
    ];
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);

?>
