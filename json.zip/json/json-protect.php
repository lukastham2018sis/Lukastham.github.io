<?php
require_once '../model/token.php';
require_once 'json-common.php';

$errors = [];

$errors = [ isMissingOrEmpty ('token')];

$errors = array_filter($errors);

if (empty($errors)) {
    $token = $_REQUEST['token'];
    $isok = verify_token($token);
    if ($isok != TRUE) {
        $errors[] = 'invalid token';
    }
}
 ?>
