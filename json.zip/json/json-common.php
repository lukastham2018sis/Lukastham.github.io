<?php
// autoloading classes needed
spl_autoload_register(function ($class_name) {
    if (file_exists("../model/" . $class_name . ".php")) {
        require_once "../model/" . $class_name . ".php";
    }
    elseif (file_exists($class_name . ".php")) {
        require_once $class_namse . ".php";
    }
});

//setting global date variable
date_default_timezone_set('Asia/Singapore');
$today = date("d/m/y H:i");

//check current Round
$RoundDAO = new RoundDAO();
$current_round = $RoundDAO -> currentRound();
$RoundID = $current_round[0] -> getRoundID();

if ($RoundID == 0) {
    $active_round = FALSE;
}
else {
    $active_round = TRUE;
}

//loading of required functions
function isMissingOrEmpty($name) {
    if(isset($_REQUEST['r']) && $name != 'token'){
        $check = json_decode($_REQUEST['r'],true);
        if (!isset($check[$name])) {
            return "missing $name";
        }
        // client did send the value over
        $value = $check[$name];
        if (empty($value)) {
            return "blank $name";
        }
    }
    else{
        if (!isset($_REQUEST[$name])) {
            return "missing $name";
        }
        // client did send the value over
        $value = $_REQUEST[$name];
        if (empty($value)) {
            return "blank $name";
        }
    }
}

 ?>
