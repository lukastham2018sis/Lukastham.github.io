<?php
//loading common files required for processing
require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "message" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$errors = [];
if (!isset($_FILES['bootstrap-file'])) {
    $errors = ['missing bootstrap-file'];
}
elseif ($_FILES['bootstrap-file']['size'] <= 0) {
    $errors = ['missing bootstrap-file'];
}

$errors = array_filter($errors);

//bootstrap process will begin if there are no errors
if (empty($errors)) {
    require_once '../model/bootstrap-process.php';
    $output = doBootstrap();
}

//return results via Json
if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "message" => array_values($errors)
    ];
}
else {
    $result = $output;
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);

 ?>
