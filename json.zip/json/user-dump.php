<?php
//loading common files required for processing
require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "message" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$errors = [];
$errors = [isMissingOrEmpty ('userid')];
$errors = array_filter($errors);

//dump-user process will begin if there are no errors
if (empty($errors)) {
    $user_input = json_decode($_REQUEST['r']);
    $StudentDAO = new StudentDAO;
    $UserID = $user_input -> userid;
    $data_call = $StudentDAO -> get($UserID);
    if ($data_call) {
        $Password = $data_call -> getPassword();
        $Name = $data_call->getName();
        $School = $data_call->getSchool();
        $eDollar = $data_call->getEcredits();
        $eDollar = round($eDollar,1);
        $output = [
            "status" => "success",
            "userid" => $UserID,
            "password" => $Password,
            "name" => $Name,
            "school" => $School,
            "edollar" => (float)$eDollar
        ];
    }
    else {
        $errors[] = 'invalid userid';
    }
}

//return results via Json
if (!empty($errors)) {
    asort($errors);
    $result = [
        "status" => "error",
        "message" => array_values($errors)
            ];
    }
    else {

        $result = $output;
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION);

 ?>
