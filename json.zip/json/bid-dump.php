<?php
//loading common files required for processing
require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
    "status" => "error",
    "message" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$errors = [];
$errors = [isMissingOrEmpty ('course'),isMissingOrEmpty ('section')];
$errors = array_filter($errors);

//dump-user process will begin if there are no errors
if (empty($errors)) {
    $SectionID = $user_input -> section;
    $CourseID = $user_input -> course;
    //check if course exists
    $CourseDAO = new CourseDAO;
    $isok_course = $CourseDAO -> retrieveCourseByID($CourseID);
    if (!$isok_course) {
        $errors[] = 'invalid course';
    }
    else {
        $SectionDAO = new SectionDAO;
        $isok_section = $SectionDAO -> retrieveSectionDetailsBySectionCourse($CourseID, $SectionID);
        if (!$isok_section) {
            $errors[] = 'invalid section';
        }
        else {
            if ($active_round) {
                $BidDAO = new BidDAO;
                $all_bids = $BidDAO -> retrieveAll();
                $increment = 1;
                $bids = [];
                foreach ($all_bids as $bid_info) {
                    $UserID = $bid_info -> getUserID();
                    $Amount = $bid_info -> getAmount();
                    $Amount = round($Amount,1);
                    $bids[] = [
                        "row" => $increment,
                        "userid" => $UserID,
                        "amount" => (float)$Amount,
                        "result" => "-"
                    ];
                    $increment ++;
                }
            }
            else {
                $RoundDAO = new RoundDAO;
                $next_round = $RoundDAO -> UpcomingRounds();
                if (sizeof($next_round) == 2) {
                    $errors[] = 'no bid information avaliable';
                }
                elseif (empty($RoundDAO))) {
                    $previous = '2';
                }
                else {
                    $previous = '1';
                }
                if (empty($errors)) {
                    $BidHistoryDAO = new BidHistoryDAO;
                    $all_bids = $BidHistoryDAO -> retriveAllBidsbyRound($previous);
                    $increment = 1;
                    $bids = [];
                    $possible_results = ['out','in'];
                    foreach ($all_bids as $bid_info) {
                        $UserID = $bid_info -> getUserID();
                        $Amount = $bid_info -> getAmount();
                        $Amount = round($Amount,1);
                        $BidStatus = $bid_info -> getBidStatus();
                        $result = $possible_results[$BidStatus];
                        $bids[] = [
                            "row" => $increment,
                            "userid" => $UserID,
                            "amount" => (float)$Amount,
                            "result" => $result
                        ];
                        $increment ++;
                    }
                }

            }
        }
    }

//return results via Json
if (!empty($errors)) {
    $result = [
    "status" => "error",
    "message" => array_values($errors)
        ];
}
else {
    $result = [
        "status" => "success",
        $bids
    ];
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION);

 ?>
