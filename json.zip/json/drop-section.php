<?php

require_once 'json-common.php';
#require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
        "status" => "error",
        "message" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$errors = [];
$errors = [isMissingOrEmpty ('course'),isMissingOrEmpty ('section'),isMissingOrEmpty ('userid')];
$errors = array_filter($errors);

if (empty($errors)) {
    $user_input = json_decode($_REQUEST['r'],true);
    $BidDAO = new BidDAO();
    $StudentDAO = new StudentDAO();
    $CourseDAO = new CourseDAO();
    $SectionDAO = new SectionDAO();
    $BidHistoryDAO = new BidHistoryDAO();
    $Round2DAO = new Round2DAO();
    //check actual input
    $UserID = $user_input['userid'];
    $CourseID = $user_input['course'];
    $SectionID = $user_input['section'];

    $check_bid_history = $BidHistoryDAO -> retrievebyUserIDCourseIDSectionID($UserID, $CourseID, $SectionID);
    foreach ($check_bid_history as $bids) {
        $processed_bid_status = $bids ->getBidStatus();
    }
    $errors[] = $processed_bid_status;
    $current_bid_course = $CourseDAO->retrieveCourseByID($CourseID);
    $current_bid_section = $SectionDAO->retrieveSectionDetailsBySectionCourse($CourseID, $SectionID);
    $Student_Details = $StudentDAO->get($UserID);

    if ($current_bid_course == FALSE) {
        $errors[] = 'invalid course';
    }
    elseif ($current_bid_section == null) {
        $errors[] = 'invalid section';
    }
    //invalid userid
    if ($Student_Details == FALSE) {
        $errors[] = 'invalid userid';
    }

    if ($RoundID != 2) {
        $errors[] = 'round not active';
    }

    if (empty($check_bid) || $processed_bid_status == 0) {
        $errors[] = 'no such bid';
    }

    if (empty($errors)) {
        $AmountBidded = $BidHistoryDAO->GetBidHistoryAmountbyUser($UserID, $CourseID, $SectionID);
        $DropResult = $BidHistoryDAO->RemoveBidHistorybyUser($UserID, $CourseID, $SectionID);
        $Size = $SectionDAO -> getSize($CourseID, $SectionID);
        $Size += 1;
        $UpdateSectionSize = $SectionDAO -> updateSize($CourseID, $SectionID, $Size);
        $number_of_bids = $BidDAO -> SearchBidsbyCourseSection($CourseID, $SectionID);
        if ($RoundID == 2) {
            if ($Size == 0) {
                $R2Size = $Round2DAO -> getSize($CourseID,$SectionID);
                $R2Size += 1;
                $To_Update = $Round2DAO -> updateSize($CourseID, $SectionID, $R2Size);
                // change min_bid to minimum bid from bid table.
                if (sizeof($number_of_bids) > 0) {
                $check_list = [];
                foreach ($number_of_bids as $bid) {
                    $check_list[] = $bid->getAmount();
                }
                $Minimum_Bid = min($check_list) + 1;
                $Update_Min_Bid = $Round2DAO -> UpdateMin_Bid($CourseID, $SectionID, $Minimum_Bid);
                }
            }
        }

        if ($DropResult == FALSE) {

            $errors[] = 'Error with dropping section';
        }
        else {
            $CurrentAmount = $StudentDAO->retrieveECredit($UserID);
            $NewAmount = number_format($AmountBidded + $CurrentAmount,2);
            $StudentDAO->addECredit($UserID, $NewAmount);
            }
        }
    asort($errors);
    }

if (!empty($errors)) {
    $result = [
        "status" => "error",
        "message" => array_values($errors)
            ];
}
else {
    $result = [
        "status" => "success"
    ];
}

#header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);



?>
