<?php

require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
        "status" => "error",
        "message" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$errors = [];
$errors = [isMissingOrEmpty ('course'),isMissingOrEmpty ('section'),isMissingOrEmpty ('userid')];
$errors = array_filter($errors);

if (empty($errors)) {
    $user_input = json_decode($_REQUEST['r']);
    //open DAO connection
    $BidDAO = new BidDAO();
    $StudentDAO = new StudentDAO();
    $CourseDAO = new CourseDAO();
    $SectionDAO = new SectionDAO();
    //check actual input
    $UserID = $user_input->userid;
    $CourseID = $user_input->course;
    $SectionID = $user_input->section;
    $all_bids = $BidDAO -> SearchBidsbyCourseSection($CourseID, $SectionID);
    $check_bid = $BidDAO -> SearchBidsbyUserCourseSection($UserID, $CourseID, $SectionID);
    $Student_Details = $StudentDAO->get($UserID);
    $current_bid_course = $CourseDAO->retrieveCourseByID($CourseID);
    $current_bid_section = $SectionDAO->retrieveSectionDetailsBySectionCourse($CourseID, $SectionID);

    if ($current_bid_course == FALSE) {
        $errors[] = 'invalid course';
    }
    elseif ($current_bid_section == null) {
        $errors[] = 'invalid section';
    }
    if ($Student_Details == FALSE) {
        $errors[] = 'invalid userid';
    }
    if ($RoundID != 1 && $RoundID != 2) {
        $errors[] = 'round ended';
    }
    if (empty($errors)) {
        if (empty($check_bid)) {
            $errors[] = 'no such bids';
        }
    }

    if (empty($errors)) {
        $AmountBidded = $BidDAO->getBidAmount($UserID, $CourseID, $SectionID);
        $dropResult = $BidDAO->DeleteBid($UserID, $CourseID, $SectionID);
        if ($dropResult == FALSE) {
            $errors[] = 'Sorry, there is a problem deleting your bid';
        }
        else {
            $currentAmount = $StudentDAO->retrieveECredit($UserID);
            $newAmount = number_format($AmountBidded + $currentAmount,2);
            $StudentDAO->addECredit($UserID, $newAmount);
        }
    }
}

asort($errors);

if (!empty($errors)) {
    $result = [
        "status" => "error",
        "message" => array_values($errors)
            ];
}
else {
    $result = [
        "status" => "success",
    ];
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);



?>
