<?php
require_once 'json-common.php';
require_once 'json-protect.php';

if (!empty($errors)) {
    asort($errors);
    $result = [
        "status" => "error",
        "message" => array_values($errors)
    ];

    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

$errors = [];
$errors = [isMissingOrEmpty ('amount'),isMissingOrEmpty ('course'),isMissingOrEmpty ('section'),isMissingOrEmpty ('userid')];
$errors = array_filter($errors);

if (empty($errors)) {

    $BidDAO = new BidDAO();
    $CourseDAO = new CourseDAO();
    $SectionDAO = new SectionDAO();
    $StudentDAO = new StudentDAO();
    $Round2DAO = new Round2DAO();
    $BidHistoryDAO = new BidHistoryDAO();
    $PrerequisiteDAO = new PrerequisiteDAO();

    $errors = [];
    $user_input = json_decode($_GET['r']);
    if (empty($errors)) {
        //check actual input
        $UserID = $user_input->userid;
        $Amount = $user_input->amount;
        $CourseID = $user_input->course;
        $SectionID = $user_input->section;
        $all_bids = $BidDAO -> SearchBidsbyCourseSection($CourseID, $SectionID);
        $check_bid = $BidDAO -> SearchBidsbyUserCourseSection($UserID, $CourseID, $SectionID);
        $Student_Details = $StudentDAO->get($UserID);
        $current_bid_course = $CourseDAO->retrieveCourseByID($CourseID);
        $current_bid_section = $SectionDAO->retrieveSectionDetailsBySectionCourse($CourseID, $SectionID);

        if ($current_bid_course == FALSE) {
            $errors[] = 'invalid course';
        }
        //invalid section
        if ($current_bid_section == null) {
            $errors[] = 'invalid section';
        }
        //invalid userid
        if ($Student_Details == FALSE) {
            $errors[] = 'invalid userid';
        }

        if (is_float($Amount + 0)) {
            $whole = floor($Amount);      // 1
            $fraction = $Amount - $whole; // .25
            if ($fraction != 0) {
                $CheckProcessedAmount = explode(".", $Amount);
                if ($CheckProcessedAmount != []) {
                    if (strlen($CheckProcessedAmount[1]) > 2) {
                        $errors[] = 'invalid amount';
                    }
                }
            }
        }
        //check for student e$
        if ($Amount < 10 || !is_numeric($Amount)) {
            $errors[] = 'invalid amount';
        }

        if (empty($check_bid) && empty($errors)) {
            $user_bid = $BidHistoryDAO -> retrievebyUserIDBidStatus($UserID,TRUE);
            $user_bid_current = $BidDAO -> getBidbyUserID($UserID);
            $Student_Amount = $Student_Details -> getEcredits();
            $Min_Bid = $Round2DAO->GetMinBidSizefromCourseSection($CourseID,$SectionID);
            $student_total_money = $StudentDAO-> retrieveECredit($UserID);
            // check course, check section, check userid, check exam and timetable clash, incomplete prereq... everything in bid-process. add if r1, check min_bid if r2.
            $current_bid_classday = $current_bid_section -> getDay();
            $current_bid_classStartTime = $current_bid_section -> getStartTime();
            $current_bid_classEndTime = $current_bid_section -> getEndTime();
            $current_bid_examDate = $current_bid_course -> getExamDate();
            $current_bid_examStartTime = $current_bid_course -> getExamStart();
            $current_bid_examEndTime = $current_bid_course -> getExamEnd();

            if ($Amount > $Student_Amount) {
                $errors[] = 'insufficient e$';
            }

            if ($RoundID == 2) {
                if ($Amount < $Min_Bid) {
                    $errors[] = 'bid too low';
                }
            }
            $userCourses = [];
            //check for class clash in successful bid
            foreach ($user_bid as $subject) {
                $class_CourseID = $subject -> getCourseID();
                $class_SectionID = $subject -> getSectionID();
                $section = $SectionDAO -> retrieveSectionDetailsBySectionCourse($class_CourseID, $class_SectionID);
                $class_day = $section -> getDay();
                $class_StartTime = $section -> getStartTime();
                $class_EndTime = $section -> getEndTime();
                $userCourses[] = $class_CourseID;
                $subject_course = $CourseDAO -> retrieveCourseByID($class_CourseID);
                $class_examDate = $subject_course -> getExamDate();
                $class_examStartTime = $subject_course -> getExamStart();
                $class_examEndTime = $subject_course -> getExamEnd();
                if ($current_bid_classday == $class_day) {
                    if ($current_bid_classStartTime == $class_StartTime OR $current_bid_classEndTime == $class_EndTime OR ($current_bid_classStartTime > $class_StartTime && $current_bid_classEndTime <= $class_EndTime) OR ($current_bid_classStartTime < $class_StartTime && $current_bid_classEndTime >= $class_EndTime)) {
                        $errors[] = 'class timetable clash';
                    }
                }
                if ($current_bid_examDate == $class_examDate) {
                    if ($current_bid_examStartTime == $class_examStartTime OR $current_bid_examEndTime == $exam_EndTime OR ($current_bid_examStartTime > $class_examStartTime && $current_bid_examEndTime <= $class_examEndTime) OR ($current_bid_examStartTime < $class_examStartTime && $current_bid_examEndTime >= $class_examEndTime)) {
                        $errors[] = 'exam timetable clash';
                        }
                    }
                }

            foreach ($user_bid_current as $subject) {
                $class_CourseID = $subject -> getCourseID();
                $class_SectionID = $subject -> getSectionID();
                $section = $SectionDAO -> retrieveSectionDetailsBySectionCourse($class_CourseID, $class_SectionID);
                $class_day = $section -> getDay();
                $class_StartTime = $section -> getStartTime();
                $class_EndTime = $section -> getEndTime();
                $subject_course = $CourseDAO -> retrieveCourseByID($class_CourseID);
                $class_examDate = $subject_course -> getExamDate();
                $class_examStartTime = $subject_course -> getExamStart();
                $class_examEndTime = $subject_course -> getExamEnd();
                if ($current_bid_classday == $class_day) {
                    if ($current_bid_classStartTime == $class_StartTime OR $current_bid_classEndTime == $class_EndTime OR ($current_bid_classStartTime > $class_StartTime && $current_bid_classEndTime <= $class_EndTime) OR ($current_bid_classStartTime < $class_StartTime && $current_bid_classEndTime >= $class_EndTime)) {
                        $errors[] = 'class timetable clash';
                    }
                }
                if ($current_bid_examDate == $class_examDate) {
                    if ($current_bid_examStartTime == $class_examStartTime OR $current_bid_examEndTime == $exam_EndTime OR ($current_bid_examStartTime > $class_examStartTime && $current_bid_examEndTime <= $class_examEndTime) OR ($current_bid_examStartTime < $class_examStartTime && $current_bid_examEndTime >= $class_examEndTime)) {
                        $errors[] = 'exam timetable clash';
                    }
                }
            }

            $allPrerequisiteCourses = $PrerequisiteDAO->retrievePrerequisitebyCourse($CourseID);
            $preReq = [];
            if ($allPrerequisiteCourses != NULL) {
                foreach ($allPrerequisiteCourses as $courses) {
                    $preReq[] = $courses -> getPreReq();
                }
            }

            if ($preReq != []) {
                foreach ($preReq as $courseNeedtoClear) {
                    if (!in_array($courseNeedtoClear, $userCourses)) {
                        $errors[] = 'incomplete prerequisites';
                    }
                }
            }

            if (sizeof($user_bid_current) == 5){
                $errors[] = 'section limit reached';
            }

            $allUserCourses = [];
            foreach ($user_bid_current as $bids) {
                $allUserCourses[] = $bids->getCourseID();
            }

            foreach ($allUserCourses as $coursesBiddedFor) {
                if ($CourseID == $coursesBiddedFor) {
                    $errors[] = 'course enrolled';
                }
            }

            //check whether class have more than one vacancy
            $sizeOfClass = $SectionDAO->getSize($CourseID, $SectionID);
            if ($sizeOfClass == 0) {
                $errors[] = 'no vacancy';
            }

            if ($RoundID != 1 && $RoundID != 2) {
                $errors[] = 'round ended';
            }

            $CompletedCourses = [];
            foreach ($user_bid as $completed_bids) {
                if ($CourseID == $completed_bids -> getCourseID()) {
                    $errors[] = 'course completed';
                    break;
                }
            }

            if ($RoundID == 1) {
                $courseSchool = $CourseDAO -> retrieveSchoolByCourseID($CourseID);
                $userSchool = $StudentDAO -> retrieveSchoolByUserID($UserID);

                if ($courseSchool != $userSchool) {
                    $errors[] = 'not own school course';
                }
            }

        }

        if (empty($errors)) {
            if (!empty($check_bid)) {
                $Amount_Student_Bidded = $BidDAO -> getBidAmount($UserID, $CourseID, $SectionID);
                if ($Amount > $Amount_Student_Bidded) {
                    $Amount_Deducted = number_format($Amount - $Amount_Student_Bidded,2);
                    $Money_to_store = $student_total_money - $Amount_Deducted;
                    $StudentDAO -> deductECredits($UserID,$Money_to_store);
                }
                elseif ($Amount < $Amount_Student_Bidded) {
                    $Amount = number_format($Amount_Student_Bidded - $Amount,2);
                    $Amount_Student_Bidded = $BidDAO -> getBidAmount($UserID, $CourseID, $SectionID);
                    $Extra_Amount = numberformat($Amount_Student_Bidded - $Amount,2);
                    $Money_to_store = $student_total_money + $Extra_Amount;
                    $StudentDAO -> addECredit($UserID, $Money_to_store);
                }
                $bidresult = $BidDAO -> updateBid($UserID, $CourseID, $SectionID, $Amount);
                if (!$bidresult) {
                    $errors[] = 'Error in bidding';
                }
            }
            else {
                $amount_left = number_format($student_total_money - $Amount,2);
                $deductResult = $StudentDAO->deductECredits($UserID, $amount_left);
                if ($deductResult) {
                    $bidresult = $BidDAO-> PlaceBid($UserID,$CourseID,$Amount,$SectionID);
                    if ($bidresult) {
                        if ($RoundID == 2) {
                            $Minimum_Bid = $Round2DAO -> GetMinBidSizefromCourseSection($CourseID,$SectionID);
                            $all_bids = $BidDAO -> SearchBidsbyCourseSection($CourseID, $SectionID);
                            $Size = $SectionDAO -> getSize($CourseID,$SectionID);
                            $Does_Course_Exist = $Round2DAO -> retrieve($CourseID, $SectionID);
                            $Number_Of_Dropped_Bids = $Round2DAO -> getSize($CourseID,$SectionID);
                            if ($Size == count($all_bids) && $Minimum_Bid == NULL) {
                                $Bids_Processing = [];
                                foreach ($all_bids as $curr_bids) {
                                    $Bids_Processing[] = $curr_bids -> getAmount();
                                }
                                $Minimum_Bid = min($Bids_Processing);
                                if ($Does_Course_Exist == []) {
                                    $Round2DAO -> AddRound2Information($CourseID, $SectionID, $Minimum_Bid+1, $Size);
                                }
                                else {
                                    $Round2DAO -> UpdateMin_Bid($CourseID, $SectionID, $Minimum_Bid+1);
                                }
                            }
                            elseif($Size < count($all_bids) || $Minimum_Bid != NULL) {
                                $Minimum_Bid = $Minimum_Bid + 1;
                                $Round2DAO -> UpdateMin_Bid($CourseID, $SectionID, $Minimum_Bid);
                            }
                            elseif ($Size < count($all_bids) && $Minimum_Bid == NULL && $Number_Of_Dropped_Bids == count($all_bids)) {
                                $Minimum_Bid = $Bid_Amount + 1;
                                $Round2DAO -> UpdateMin_Bid($CourseID, $SectionID, $Minimum_Bid);
                            }
                        }
                }
                    else {
                        $errors[] = 'Error in bidding';
                    }
                }
                else {
                    $errors[] = 'Error in eDollar deduction';
                }

            }

        }
    }
}
asort($errors);

if (!empty($errors)) {
    $result = [
        "status" => "error",
        "message" => array_values($errors)
            ];
}

else {
    $result = [
        "status" => "success",
    ];
}


header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);

?>
